package com.model;

import org.springframework.stereotype.Component;

@Component
public class Student 
{
	public Student()
	{
		System.out.println("This is Constructor");
	}
	
	public void display()
	{
		System.out.println("Display");
	}

}
