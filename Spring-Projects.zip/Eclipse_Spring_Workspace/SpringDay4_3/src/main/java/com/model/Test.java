package com.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.*;
public class Test
{
	public static void main(String[] args)
	{
		
		ApplicationContext ac = new ClassPathXmlApplicationContext("beans.xml");
		
		CollectionType c = ac.getBean("c", CollectionType.class);
		
		List<String> l = c.getNames();
		for(String s : l)
		{
			System.out.println(s);
		}
		
		Set<Integer> s = c.getRollnos();
		for(int i : s)
		{
			System.out.println(i);
		}
		
		Map<String,Integer> map = c.getCountries();
		Set<String> keys = map.keySet();
		
		for(String key : keys)
		{
			System.out.println(key);
			System.out.println(map.get(key));
		}
	}

}
