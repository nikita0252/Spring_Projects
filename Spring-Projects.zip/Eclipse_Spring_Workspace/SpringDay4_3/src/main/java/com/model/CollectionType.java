package com.model;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class CollectionType 
{
	private List<String> names;
	private Set<Integer> rollnos;
	private Map<String,Integer> countries;
	public List<String> getNames() {
		return names;
	}
	public void setNames(List<String> names) {
		this.names = names;
	}
	public Set<Integer> getRollnos() {
		return rollnos;
	}
	public void setRollnos(Set<Integer> rollnos) {
		this.rollnos = rollnos;
	}
	public Map<String, Integer> getCountries() {
		return countries;
	}
	public void setCountries(Map<String, Integer> countries) {
		this.countries = countries;
	}
	
	

}
