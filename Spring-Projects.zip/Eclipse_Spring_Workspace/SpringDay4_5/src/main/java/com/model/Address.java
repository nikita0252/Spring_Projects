package com.model;

public class Address 
{
	private String aname;

	public String getAname() {
		return aname;
	}

	public void setAname(String aname) {
		this.aname = aname;
	}
	
	

	
}
