package com.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test 
{
	public static void main(String[] args) 
	{
		ApplicationContext a = new ClassPathXmlApplicationContext("beans.xml");
		Employee e= (Employee) a.getBean("emp");
		
		System.out.println(e);
		e.setEmpid(105);
		System.out.println(e.getEmpid());
		System.out.println(e.getEmpname());
		System.out.println(e.getEmpmobno());
		System.out.println(e.getEmpadr());
		System.out.println();
		
		Employee ep= (Employee) a.getBean("emp");
		System.out.println(ep);
		System.out.println();
		
		Employee e1 = (Employee) a.getBean("emp1");
		System.out.println(e1);
		System.out.println(e1.getEmpid());
		System.out.println(e1.getEmpname());
		System.out.println(e1.getEmpmobno());
		System.out.println(e1.getEmpadr());
		System.out.println();
		
		Employee ep1 = (Employee) a.getBean("emp1");
		System.out.println(ep1);
		
	
		
		
		
	}

}
