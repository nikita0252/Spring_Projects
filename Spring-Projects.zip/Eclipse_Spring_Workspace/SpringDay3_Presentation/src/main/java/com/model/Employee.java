package com.model;

public class Employee 
{
	private int empid;
	private String empname;
	private long empmobno;
	private String empadr;
	
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public long getEmpmobno() {
		return empmobno;
	}
	public void setEmpmobno(long empmobno) {
		this.empmobno = empmobno;
	}
	public String getEmpadr() {
		return empadr;
	}
	public void setEmpadr(String empadr) {
		this.empadr = empadr;
	}
	
	

}
