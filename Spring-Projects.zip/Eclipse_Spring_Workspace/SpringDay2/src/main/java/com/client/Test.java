package com.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.model.Employee;

public class Test {
	public static void main(String[] args) {

		ApplicationContext ac = new ClassPathXmlApplicationContext("beans.xml");

		Employee er = (Employee) ac.getBean("e");

		System.out.println(er);
		System.out.println(er.getId());
		System.out.println(er.getName());
		System.out.println(er.getAddr());


	}

}
