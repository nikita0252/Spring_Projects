package com.model;

public class Student 
{
	public Student()
	{
		System.out.println("Student Constructor");
	}

}
