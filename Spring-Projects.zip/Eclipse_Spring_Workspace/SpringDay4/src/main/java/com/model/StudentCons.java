package com.model;

public class StudentCons 
{
	
	private int rollno;
	private String name;
	
	public StudentCons(int roll,String name)
	{
		rollno=roll;
		this.name=name;
		
	}
	
	public void display()
	{
		System.out.println("Hello Student Constructor");
		System.out.println(rollno);
		System.out.println(name);
	}

}
