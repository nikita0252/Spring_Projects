package com.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test 

{
	public static void main(String[] args) 
	{
		ApplicationContext ac = new ClassPathXmlApplicationContext("beans.xml");
		EmpSettPrototype e =(EmpSettPrototype)ac.getBean("es");
		
		System.out.println(e);
		System.out.println(e.getId());
		System.out.println(e.getName());
		System.out.println(e.getMobno());
		System.out.println(e.getSalary());
		
		EmpSettPrototype e1 =(EmpSettPrototype)ac.getBean("eps");
		
		System.out.println(e1);
		System.out.println(e1.getId());
		System.out.println(e1.getName());
		System.out.println(e1.getMobno());
		System.out.println(e1.getSalary());
		
		
	}

}
