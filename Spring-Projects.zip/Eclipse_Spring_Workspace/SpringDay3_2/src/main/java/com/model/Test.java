package com.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test 
{
	
	public static void main(String[] args) 
	{
		ApplicationContext a = new ClassPathXmlApplicationContext("beans.xml");
		
		EmpSettBased e= (EmpSettBased) a.getBean("es");
		
		System.out.println(e.getId());
		System.out.println(e.getName());
		System.out.println(e.getMobno());
		System.out.println(e.getSalary());
		System.out.println("");
		
		EmpSettBased e1= (EmpSettBased) a.getBean("est");
		
		System.out.println(e1.getId());
		System.out.println(e1.getName());
		System.out.println(e1.getMobno());
		System.out.println(e1.getSalary());
		
	}

}
