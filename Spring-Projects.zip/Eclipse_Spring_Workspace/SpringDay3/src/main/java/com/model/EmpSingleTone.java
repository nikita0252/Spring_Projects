package com.model;

public class EmpSingleTone 
{
	public EmpSingleTone()
	{
		System.out.println("This is Employee Constructor");
	}

}
