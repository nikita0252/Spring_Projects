package com.model;

public class Employee 
{
	public Employee(int i)
	{
		System.out.println("This is Employee's Constructor..");
		System.out.println("i ="+ i);
	}

}
