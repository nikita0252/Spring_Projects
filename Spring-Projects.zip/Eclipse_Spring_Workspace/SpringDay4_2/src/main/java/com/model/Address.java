package com.model;

public class Address 
{
	private String city;
	private String location;
	
	public Address(String city,String location)
	{
		this.city=city;
		this.location=location;
	}
	
	public String toString()
	{
		return "city"+" "+getCity()+" "+ "location"+" "+getLocation();
	}
	
	public void display()
	{
		System.out.println("City:"+city);
		System.out.println("Location :"+location);
		
	}


	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	
	

}
