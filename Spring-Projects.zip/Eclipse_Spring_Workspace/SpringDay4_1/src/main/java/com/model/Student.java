package com.model;

public class Student 
{
	private Address adr;

	public Address getAdr() 
	{
		return adr;
	}

	public void setAdr(Address adr) 
	{
		this.adr = adr;
	}
	
	

}
