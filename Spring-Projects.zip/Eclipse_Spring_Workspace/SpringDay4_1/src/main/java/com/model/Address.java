package com.model;

public class Address
{
	private String areaname;

	public String getAreaname() 
	{
		return areaname;
	}

	public void setAreaname(String adr) 
	{
		this.areaname = areaname;
	}
	
	

}
