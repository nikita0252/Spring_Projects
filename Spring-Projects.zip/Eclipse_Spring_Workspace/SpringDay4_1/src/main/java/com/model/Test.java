package com.model;

public class Test 
{
	public static void main(String[] args) 
	{
	 ApplicationContext a = new Clas
		
	}

}
