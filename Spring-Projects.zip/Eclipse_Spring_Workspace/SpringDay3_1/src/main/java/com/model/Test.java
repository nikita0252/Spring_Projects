package com.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test 
{
	public static void main(String[] args) 
	{
		ApplicationContext ac = new ClassPathXmlApplicationContext("beans.xml");
		 
		EmpPrototype e = (EmpPrototype) ac.getBean("ep");
		System.out.println(e);
		
		EmpPrototype e1 = (EmpPrototype) ac.getBean("ep");
		System.out.println(e1);
		
	}

}
