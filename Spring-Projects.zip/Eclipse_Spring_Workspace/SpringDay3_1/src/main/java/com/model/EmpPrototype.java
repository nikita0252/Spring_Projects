package com.model;

public class EmpPrototype 
{
	public EmpPrototype()
	{
		System.out.println("This is EmpPrototype");
	}


}
